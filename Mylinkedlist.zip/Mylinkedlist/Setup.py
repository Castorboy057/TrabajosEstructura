from setuptools import find_packages, setup

setup(
    name="Biblioteca",
    version="0.2",
    packages=find_packages(),
    py_modules=["Biblioteca"],
)